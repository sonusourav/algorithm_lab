package assignment2_solutions;

public enum InputType {
  insert, inorder, preorder, postorder, search, minimum, maximum, successor, predecessor;  
}
