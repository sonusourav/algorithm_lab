## For compiling the program, follow the below steps:
- Unzip the zipped file.
- Open terminal in the 170020021 folder such that current folder in the which terminal is opened should contain `assignment2_solutions` folder.
- Make sure the input files are location in the 170020021 folder in which the terminal is opened.
- Run this command `javac ./assignment2_solutions/JAVA_170020021.java` to compile.
- Run this command `java -classpath . assignment2_solutions.BST ./<input_file>.txt` to run the program.

`

