 For compiling the program, follow the below steps:
- Unzip the zipped file.
- Open terminal in the 170020021 folder such that current folder in the which terminal is opened should contain `assignment_5` folder.
- Run this command `javac ./assignment_5/TOH.java` to compile.
- Run this command `java -classpath . assignment_5.TOH <input_size>` to run the program.